#include<conio.h>
#include<stdio.h>
#include<stdlib.h>


/*Fa�a uma fun��o que recebe um valor inteiro e verifica se o valor � positivo ou
negativo. A fun��o deve retornar 1 para positivo e 0 para negativo. 
*/

int valida(int a){
	int soma;
	if(a > 0){
		return 1;
	}else{
		return 0;
	}
}

main(){
	int b;
	printf("digte o valor: \n");
	scanf("%d", &b);
	if( valida(b) == 1)
	printf("%d - Positivo", valida(b));
	else
	printf("%d - Negativo", valida(b));
}

