#include<conio.h>
#include<stdio.h>
#include<stdlib.h>


/*
criar uma fun��o para verificar se o numero inteiro recebido por parametro � par ou impar.
 Se for par deve ser retornado 0, se for impar deve retornar 1
*/


int valida(int a){
	int soma;
	if(a%2 == 0){
		return 0;
	}else{
		return 1;
	}
}

main(){
	int b;
	printf("digte o valor: \n");
	scanf("%d", &b);
	
	if(valida(b) == 0)
		printf("Numero Par");
	else
		printf("Numero Impar");
	
}
