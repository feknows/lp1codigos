#include<conio.h>
#include<stdio.h>
#include<stdlib.h>


/*
Declare um vetor de inteiros com 10 posi��es, esta declara��o deve ser global.
Crie um procedimento para preencher o vetor e uma fun��o para exibir a soma
dos valores. 
*/

void rando (){
	int cont;
	for ( cont = 0; cont < 10; cont ++){
		printf("cont");
	}
};

main(){
	void rando();
}
