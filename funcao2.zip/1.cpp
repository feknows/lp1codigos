#include<conio.h>
#include<stdio.h>
#include<stdlib.h>



/*
Crie um procedimento que receba por par�metro dois valores reais (float) e execute a
subtra��o do primeiro valor pelo segundo, em seguida exiba o resultado.

*/

struct valores{
	float x,y;
};

valores valores;
void preenche(){	
	printf("\nValor x e y: ");
	scanf("%f%f", &valores.x, &valores.y);
}

void sub(){
	
printf("\nValor x - y =: %.2f", valores.x-valores.y);	
}
	
	

main(){
	int op;
	do{
		printf("\n0 = sair\n");
		printf("1 = preencher\n");
		printf("2 = exibir\n");
		scanf("%d", &op);
		switch(op){
			case 1:
				preenche();
				break;
			case 2:
				sub();
				break;
			} 
	}while (op!=0);



getch();
}

