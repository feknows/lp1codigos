#include<conio.h>
#include<stdio.h>
#include<stdlib.h>




int soma(int a, int b){
	return a+b;
}
main(){
int x,y;
printf("digte dois valores: \n");
scanf("%d%d", &x, &y);

printf("\n%d", soma(x, y));


}

