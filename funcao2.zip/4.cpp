#include<conio.h>
#include<stdio.h>
#include<stdlib.h>


/*Criar uma struct �cliente� com codigo, nome e rg. Declare uma vari�vel global do tipo
cliente. Crie um procedimento para preencher os dados do cliente e outro
procedimento para exibir os dados do cliente. Crie, no main, um menu para o usu�rio
poder optar por: sair, cadastrar e exibir. 
*/

struct cliente{
	int codigo;
	char nome[100];
	char rg[20];
};

cliente cli;
void preencher(){
	printf("\nCodigo: ");
	scanf("%d", &cli.codigo);
	printf("\nNome: ");
	fflush(stdin);
	gets(cli.nome);
	printf("\nRG: ");
	gets(cli.rg);
}

void exibir(){
	printf("\n %d - Nome: %s - RG: %s", cli.codigo, cli.nome, cli.rg);
}
		
main(){
	int op;
	do{
		printf("\n0 = sair\n");
		printf("1 = preencher\n");
		printf("2 = exibir\n");
		scanf("%d", &op);
		switch(op){
			case 1:
				preencher();
				break;
			case 2:
				exibir();
				break;
			} 
	}while (op!=0);
}


