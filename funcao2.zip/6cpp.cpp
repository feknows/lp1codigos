
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
/*Criar um programa com um vetor de inteiros com 100 posi��es e global. Criar um
procedimento para preencher este vetor com n�meros aleat�rios (rand) e outro
procedimento que exibir� todos os valores acima de 80
*/


int vetor[100];

void preencher(){
	int cont;
	srand(time(NULL));	
	//preenche o vetor com valores entre 0 e 200
	for(cont =0; cont<100; cont++){
		vetor[cont] = rand() % 201;
	}
}


void exibir(){
	int cont;
	for(cont=0; cont<100; cont++){
	if(vetor[cont] > 80)
		printf("%d ", vetor[cont]);
		}
	}

main(){
void preencher();

void exibir();


}

